# Food POS App

Building a Restaurant POS App to learn Next.js, TailwindCSS and Prisma.